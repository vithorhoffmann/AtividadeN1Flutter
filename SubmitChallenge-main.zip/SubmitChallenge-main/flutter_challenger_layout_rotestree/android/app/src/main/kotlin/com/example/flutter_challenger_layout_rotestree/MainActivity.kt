package com.example.flutter_challenger_layout_rotestree

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
